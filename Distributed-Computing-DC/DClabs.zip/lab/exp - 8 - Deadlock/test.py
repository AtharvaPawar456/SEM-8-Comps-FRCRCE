a = int(input("Enterrr"))
print(a)